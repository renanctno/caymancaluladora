import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const { productCost, packagingCost, shopeeFee } = await request.json()

    // Validate inputs
    const product = parseFloat(productCost) || 0
    const packaging = parseFloat(packagingCost) || 0
    const fee = parseFloat(shopeeFee) || 20

    // Always provide a fallback calculation first
    const totalCosts = product + packaging + 4.00
    let optimalPrice = totalCosts / (1 - 0.25) // Target 25% net margin
    optimalPrice = Math.ceil(optimalPrice * 100) / 100 // Round up to 2 decimal places

    try {
      const zai = await ZAI.create()

      const prompt = `
Como especialista em e-commerce e marketplace Shopee Brasil, calcule o preço ideal de venda para maximizar o lucro considerando:

- Custo do produto: R$ ${product.toFixed(2)}
- Custo da embalagem: R$ ${packaging.toFixed(2)}
- Taxa Shopee: ${fee}% sobre o valor da venda
- Tarifa fixa Shopee: R$ 4,00 por venda

Regras:
1. O preço deve ser competitivo para o mercado brasileiro
2. Margem de lucro líquida ideal entre 20-30%
3. Considere psicologia de preços (ex: R$ 99,90 em vez de R$ 100,00)
4. O preço deve cobrir todos os custos e gerar lucro saudável
5. Para produtos de baixo valor, a margem pode ser maior

Retorne APENAS o número do preço ideal com duas casas decimais, sem texto adicional.
Exemplo: 127.90
`

      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'Você é um especialista em precificação para e-commerce no Brasil, com profundo conhecimento da Shopee e do mercado varejista brasileiro.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.3,
        max_tokens: 50
      })

      const suggestedPriceText = completion.choices[0]?.message?.content?.trim()
      
      // Extract numeric value from response
      const priceMatch = suggestedPriceText?.match(/[\d.,]+/)
      
      if (priceMatch) {
        // Remove any non-numeric characters except decimal point
        const cleanPrice = priceMatch[0].replace(/[^\d.,]/g, '').replace(',', '.')
        const aiPrice = parseFloat(cleanPrice)
        
        // Validate AI price
        if (aiPrice && aiPrice > 0 && aiPrice > totalCosts) {
          optimalPrice = aiPrice
        }
      }

    } catch (aiError) {
      console.error('AI calculation failed, using fallback:', aiError)
      // Keep the fallback calculation
    }

    return NextResponse.json({
      optimalPrice,
      success: true
    })

  } catch (error) {
    console.error('Error in optimal price calculation:', error)
    
    // Emergency fallback
    try {
      const { productCost, packagingCost } = await request.json()
      const product = parseFloat(productCost) || 0
      const packaging = parseFloat(packagingCost) || 0
      const totalCosts = product + packaging + 4.00
      const optimalPrice = totalCosts / (1 - 0.25)
      
      return NextResponse.json({
        optimalPrice: Math.ceil(optimalPrice * 100) / 100,
        success: false,
        error: 'Used fallback calculation'
      })
    } catch (parseError) {
      return NextResponse.json({
        optimalPrice: 0,
        success: false,
        error: 'Invalid input parameters'
      }, { status: 400 })
    }
  }
}