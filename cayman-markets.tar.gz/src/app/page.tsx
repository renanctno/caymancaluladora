'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Button } from '@/components/ui/button'
import { Calculator, TrendingUp, DollarSign, Package, Percent, Target, BarChart3, Brain, Settings } from 'lucide-react'

export default function ShopeeCalculator() {
  const [productCost, setProductCost] = useState<string>('50.00')
  const [packagingCost, setPackagingCost] = useState<string>('5.00')
  const [salePrice, setSalePrice] = useState<string>('100.00')
  const [shopeeFee, setShopeeFee] = useState<string>('20')
  const [shopeeAdsInvestment, setShopeeAdsInvestment] = useState<string>('10.00')
  const [suggestedPrice, setSuggestedPrice] = useState<string>('72.67') // Preço inicial calculado: (50+5+4) / 0.75
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const [calculationMode, setCalculationMode] = useState<'price' | 'profit'>('price') // 'price' = calcula lucro, 'profit' = calcula preço
  const [desiredProfit, setDesiredProfit] = useState<string>('20.00') // Lucro desejado
  const [dailyProfitTarget, setDailyProfitTarget] = useState<string>('50.00') // Meta de lucro diário desejado
  const [dailyUnits, setDailyUnits] = useState<string>('10') // Unidades vendidas por dia
  const [projectionMode, setProjectionMode] = useState<'units' | 'profit'>('units') // Modo de projeção: 'units' = por unidades, 'profit' = por meta de lucro

  const fixedShopeeFee = 4.00

  const calculateResults = () => {
    const product = parseFloat(productCost) || 0
    const packaging = parseFloat(packagingCost) || 0
    const price = parseFloat(salePrice) || 0
    const fee = parseFloat(shopeeFee) || 20

    const totalFees = (price * fee / 100) + fixedShopeeFee
    const totalCosts = product + packaging + totalFees
    const netProfit = price - totalCosts
    const netMargin = price > 0 ? (netProfit / price) * 100 : 0
    const grossProfit = price - product - packaging
    const grossMargin = price > 0 ? (grossProfit / price) * 100 : 0

    return {
      totalCosts,
      netProfit,
      netMargin,
      grossProfit,
      grossMargin,
      totalFees
    }
  }

  // Calculate sale price based on desired profit
  const calculatePriceFromProfit = () => {
    const product = parseFloat(productCost) || 0
    const packaging = parseFloat(packagingCost) || 0
    const profit = parseFloat(desiredProfit) || 0
    const fee = parseFloat(shopeeFee) || 20

    // Fórmula: Preço = (Custos Fixos + Lucro Desejado) / (1 - Taxa Variável)
    // Onde Custos Fixos = Custo Produto + Custo Embalagem + Taxa Fixa
    // E Taxa Variável = Taxa Shopee / 100
    const fixedCosts = product + packaging + fixedShopeeFee
    const variableFeeRate = fee / 100
    
    // Cálculo: preço necessário para atingir o lucro desejado
    const requiredPrice = (fixedCosts + profit) / (1 - variableFeeRate)
    
    return Math.ceil(requiredPrice * 100) / 100 // Arredonda para cima com 2 casas decimais
  }

  // Marketing Calculations
  const calculateMarketingMetrics = () => {
    const ads = parseFloat(shopeeAdsInvestment) || 0
    const product = parseFloat(productCost) || 0
    const packaging = parseFloat(packagingCost) || 0
    const fee = parseFloat(shopeeFee) || 20
    const price = parseFloat(salePrice) || 0
    const dailyTarget = parseFloat(dailyProfitTarget) || 0

    // Cálculo do lucro por venda
    const totalFees = (price * fee / 100) + fixedShopeeFee
    const totalCosts = product + packaging + totalFees
    const netProfitPerSale = price - totalCosts

    // Break-even: quantas vendas para cobrir o investimento em ads
    const breakEvenSales = ads > 0 && netProfitPerSale > 0 ? ads / netProfitPerSale : 0

    // Vendas necessárias para lucro desejado (ex: R$ 100 de lucro)
    const targetProfit = 100
    const salesForTargetProfit = netProfitPerSale > 0 ? targetProfit / netProfitPerSale : 0

    // Vendas necessárias para atingir a meta de lucro diário do usuário
    const salesForDailyTarget = dailyTarget > 0 && netProfitPerSale > 0 ? dailyTarget / netProfitPerSale : 0

    // ROI e Payback
    const dailyProfit = netProfitPerSale * breakEvenSales
    const monthlyProfit = dailyProfit * 30
    const roi = ads > 0 ? ((monthlyProfit - ads * 30) / (ads * 30)) * 100 : 0
    const paybackDays = monthlyProfit > 0 ? (ads * 30) / monthlyProfit : 0

    // ROI e Payback baseado na meta diária do usuário
    const monthlyProfitFromTarget = dailyTarget * 30
    const roiFromTarget = ads > 0 ? ((monthlyProfitFromTarget - ads * 30) / (ads * 30)) * 100 : 0
    const paybackDaysFromTarget = monthlyProfitFromTarget > 0 ? (ads * 30) / monthlyProfitFromTarget : 0

    return {
      breakEvenSales,
      salesForTargetProfit,
      salesForDailyTarget,
      netProfitPerSale,
      dailyProfit,
      monthlyProfit,
      roi,
      paybackDays,
      roiFromTarget,
      paybackDaysFromTarget
    }
  }

  const calculateKPIs = () => {
    const ads = parseFloat(shopeeAdsInvestment) || 0
    const results = calculateResults()
    const breakEvenROAS = ads > 0 ? (ads / Math.abs(results.netProfit)) : 0

    return {
      breakEvenROAS
    }
  }

  const calculateOptimalPrice = async () => {
    setIsLoading(true)
    try {
      const product = parseFloat(productCost) || 0
      const packaging = parseFloat(packagingCost) || 0
      const fee = parseFloat(shopeeFee) || 20

      // First, set a fallback calculation immediately
      const totalCosts = product + packaging + fixedShopeeFee
      const fallbackPrice = totalCosts / (1 - 0.25) // Target 25% net margin
      setSuggestedPrice(Math.ceil(fallbackPrice * 100) / 100)

      const response = await fetch('/api/calculate-optimal-price', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          productCost: product,
          packagingCost: packaging,
          shopeeFee: fee
        })
      })

      if (response.ok) {
        const data = await response.json()
        if (data.optimalPrice && data.optimalPrice > 0) {
          setSuggestedPrice(data.optimalPrice.toFixed(2))
        }
      } else {
        console.error('API response not ok:', response.status)
      }
    } catch (error) {
      console.error('Error calculating optimal price:', error)
      // Set fallback calculation on error
      const product = parseFloat(productCost) || 0
      const packaging = parseFloat(packagingCost) || 0
      const totalCosts = product + packaging + fixedShopeeFee
      const fallbackPrice = totalCosts / (1 - 0.25)
      setSuggestedPrice(Math.ceil(fallbackPrice * 100) / 100)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    // Calculate initial price immediately
    const product = parseFloat(productCost) || 0
    const packaging = parseFloat(packagingCost) || 0
    const totalCosts = product + packaging + fixedShopeeFee
    const fallbackPrice = totalCosts / (1 - 0.25)
    setSuggestedPrice(Math.ceil(fallbackPrice * 100) / 100)
    
    // Then try to get AI calculation
    calculateOptimalPrice()
  }, [productCost, packagingCost, shopeeFee])

  // Update sale price when in profit mode
  useEffect(() => {
    if (calculationMode === 'profit') {
      const requiredPrice = calculatePriceFromProfit()
      setSalePrice(requiredPrice.toString())
    }
  }, [desiredProfit, productCost, packagingCost, shopeeFee, calculationMode])

  const results = calculateResults()
  const kpis = calculateKPIs()
  const marketingMetrics = calculateMarketingMetrics()

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-4">
      <div className="max-w-md mx-auto space-y-6">
        {/* Header */}
        <div className="text-center py-6">
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Calculator className="w-10 h-10 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">CAYMAN MARKETS</h1>
          <p className="text-gray-600 text-sm">Calculadora inteligente para Shopee</p>
          <Badge className="bg-orange-500 hover:bg-orange-600 mt-2">Shopee Brasil</Badge>
        </div>

        {/* Main Calculator Card */}
        <Card className="shadow-lg border-0">
          <CardHeader className="bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-t-lg">
            <CardTitle className="flex items-center gap-2">
              <Calculator className="w-5 h-5" />
              Calculadora de Preços
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="productCost" className="flex items-center gap-2 text-sm font-medium">
                <Package className="w-4 h-4" />
                Custo do Produto (R$)
              </Label>
              <Input
                id="productCost"
                type="number"
                step="0.01"
                value={productCost}
                onChange={(e) => setProductCost(e.target.value)}
                className="text-lg font-semibold"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="packagingCost" className="flex items-center gap-2 text-sm font-medium">
                <Package className="w-4 h-4" />
                Custo da Embalagem (R$)
              </Label>
              <Input
                id="packagingCost"
                type="number"
                step="0.01"
                value={packagingCost}
                onChange={(e) => setPackagingCost(e.target.value)}
                className="text-lg font-semibold"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="salePrice" className="flex items-center gap-2 text-sm font-medium">
                <DollarSign className="w-4 h-4" />
                Preço de Venda (R$)
                {calculationMode === 'profit' && (
                  <Badge variant="secondary" className="text-xs">Automático</Badge>
                )}
              </Label>
              <Input
                id="salePrice"
                type="number"
                step="0.01"
                value={salePrice}
                onChange={(e) => setSalePrice(e.target.value)}
                disabled={calculationMode === 'profit'}
                className={`text-lg font-semibold ${calculationMode === 'profit' ? 'bg-gray-100 cursor-not-allowed' : ''}`}
              />
              {calculationMode === 'profit' && (
                <div className="text-xs text-green-600">
                  ⚡ Preço calculado baseado no lucro desejado
                </div>
              )}
            </div>

            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Custo Fixo Shopee por venda:</span>
                <span className="font-semibold text-gray-900">R$ 4,00</span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="shopeeFee" className="flex items-center gap-2 text-sm font-medium">
                <Percent className="w-4 h-4" />
                Taxa Shopee (% sobre o valor)
              </Label>
              <Input
                id="shopeeFee"
                type="number"
                step="0.1"
                value={shopeeFee}
                onChange={(e) => setShopeeFee(e.target.value)}
                className="text-lg font-semibold"
              />
            </div>

            <Separator />

            {/* Mode Selector */}
            <div className="space-y-3">
              <Label className="flex items-center gap-2 text-sm font-medium">
                <Settings className="w-4 h-4" />
                Modo de Cálculo
              </Label>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant={calculationMode === 'price' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setCalculationMode('price')}
                  className="text-xs"
                >
                  Por Preço
                </Button>
                <Button
                  variant={calculationMode === 'profit' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setCalculationMode('profit')}
                  className="text-xs"
                >
                  Por Lucro
                </Button>
              </div>
            </div>

            {/* Desired Profit Field - Only show in profit mode */}
            {calculationMode === 'profit' && (
              <div className="space-y-2">
                <Label htmlFor="desiredProfit" className="flex items-center gap-2 text-sm font-medium">
                  <Target className="w-4 h-4" />
                  Quero Ganhar (R$)
                </Label>
                <Input
                  id="desiredProfit"
                  type="number"
                  step="0.01"
                  value={desiredProfit}
                  onChange={(e) => setDesiredProfit(e.target.value)}
                  className="text-lg font-semibold border-green-200 focus:border-green-400"
                  placeholder="Quanto você quer ganhar?"
                />
                <div className="text-xs text-gray-600">
                  💡 Preço calculado automaticamente: R$ {calculatePriceFromProfit().toFixed(2)}
                </div>
              </div>
            )}

            <Separator />

            <div className="bg-orange-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700">Total de Custos:</span>
                <span className="text-xl font-bold text-orange-600">
                  R$ {results.totalCosts.toFixed(2)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results Card */}
        <Card className="shadow-lg border-0">
          <CardHeader className="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-t-lg">
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              {calculationMode === 'profit' ? 'Resultado Baseado no Lucro Desejado' : 'Resultados Calculados'}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="text-sm text-gray-600 mb-1">Lucro Líquido</div>
                <div className={`text-2xl font-bold ${results.netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  R$ {results.netProfit.toFixed(2)}
                </div>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <div className="text-sm text-gray-600 mb-1">Margem Líquida</div>
                <div className={`text-2xl font-bold ${results.netMargin >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {results.netMargin.toFixed(1)}%
                </div>
              </div>
              <div className="bg-indigo-50 p-4 rounded-lg">
                <div className="text-sm text-gray-600 mb-1">Margem Bruta</div>
                <div className="text-2xl font-bold text-indigo-600">
                  {results.grossMargin.toFixed(1)}%
                </div>
              </div>
              <div className="bg-orange-50 p-4 rounded-lg">
                <div className="text-sm text-gray-600 mb-1">
                  {calculationMode === 'profit' ? 'Preço Calculado' : 'Preço Ideal Sugerido'}
                </div>
                <div className="text-xl font-bold text-orange-600">
                  {calculationMode === 'profit' 
                    ? `R$ ${calculatePriceFromProfit().toFixed(2)}`
                    : isLoading 
                      ? '...' 
                      : `R$ ${suggestedPrice}`
                  }
                </div>
                {calculationMode === 'profit' && (
                  <div className="text-xs text-gray-500 mt-1">
                    Para ganhar R$ {parseFloat(desiredProfit).toFixed(2)}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Analysis Card */}
        <Card className="shadow-lg border-0">
          <CardHeader className="bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-t-lg">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Análise de Marketing
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="shopeeAds" className="flex items-center gap-2 text-sm font-medium">
                <Target className="w-4 h-4" />
                Investimento diário em Shopee Ads (R$)
              </Label>
              <Input
                id="shopeeAds"
                type="number"
                step="0.01"
                value={shopeeAdsInvestment}
                onChange={(e) => setShopeeAdsInvestment(e.target.value)}
                className="text-lg font-semibold"
              />
            </div>

            {/* Projection Mode Selection */}
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-700">Modo de Projeção</Label>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  type="button"
                  variant={projectionMode === 'units' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setProjectionMode('units')}
                  className={`flex items-center gap-2 ${projectionMode === 'units' ? 'bg-blue-600 hover:bg-blue-700' : ''}`}
                >
                  <Package className="w-4 h-4" />
                  Por Unidades/dia
                </Button>
                <Button
                  type="button"
                  variant={projectionMode === 'profit' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setProjectionMode('profit')}
                  className={`flex items-center gap-2 ${projectionMode === 'profit' ? 'bg-green-600 hover:bg-green-700' : ''}`}
                >
                  <Target className="w-4 h-4" />
                  Por Meta de Lucro
                </Button>
              </div>
              <div className="text-xs text-gray-600">
                {projectionMode === 'units' 
                  ? '💡 Informe quantas unidades você vende por dia' 
                  : '💡 Defina sua meta de lucro diário'
                }
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="dailyProfitTarget" className="flex items-center gap-2 text-sm font-medium">
                <DollarSign className="w-4 h-4" />
                Meta de Lucro Diário (R$)
              </Label>
              <Input
                id="dailyProfitTarget"
                type="number"
                step="0.01"
                value={dailyProfitTarget}
                onChange={(e) => setDailyProfitTarget(e.target.value)}
                className="text-lg font-semibold border-green-200 focus:border-green-400"
                placeholder="Quanto você quer ganhar por dia?"
                disabled={projectionMode === 'units'}
              />
              <div className="text-xs text-gray-600">
                💡 Calcularemos quantas vendas você precisa para atingir essa meta
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="dailyUnits" className="flex items-center gap-2 text-sm font-medium">
                <Package className="w-4 h-4" />
                Unidades Vendidas por Dia
              </Label>
              <Input
                id="dailyUnits"
                type="number"
                step="1"
                value={dailyUnits}
                onChange={(e) => setDailyUnits(e.target.value)}
                className="text-lg font-semibold border-blue-200 focus:border-blue-400"
                placeholder="Quantas unidades você vende por dia?"
                disabled={projectionMode === 'profit'}
              />
              <div className="text-xs text-gray-600">
                💡 Informe suas vendas diárias para projeções mais precisas
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="text-sm text-gray-600 mb-1">Break-even ROAS</div>
                <div className="text-xl font-bold text-gray-900">
                  {kpis.breakEvenROAS.toFixed(2)}x
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="text-sm text-gray-600 mb-1">Vendas para Break-even</div>
                <div className="text-xl font-bold text-blue-600">
                  {marketingMetrics.breakEvenSales.toFixed(1)} vendas/dia
                </div>
                <div className="text-xs text-gray-500">
                  Para cobrir R$ {parseFloat(shopeeAdsInvestment).toFixed(2)} em ads
                </div>
              </div>
              {projectionMode === 'profit' && (
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Vendas para sua Meta Diária</div>
                  <div className="text-xl font-bold text-blue-600">
                    {marketingMetrics.salesForDailyTarget.toFixed(1)} vendas/dia
                  </div>
                  <div className="text-xs text-gray-500">
                    Para ganhar R$ {parseFloat(dailyProfitTarget).toFixed(2)} por dia
                  </div>
                </div>
              )}
              {projectionMode === 'units' && (
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Projeção de Lucro Diário</div>
                  <div className="text-xl font-bold text-green-600">
                    R$ {(results.netProfit && !isNaN(results.netProfit) ? (results.netProfit * parseFloat(dailyUnits)) : 0).toFixed(2)}
                  </div>
                  <div className="text-xs text-gray-500">
                    Com {parseFloat(dailyUnits).toFixed(0)} unidades vendidas por dia
                  </div>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-purple-50 p-4 rounded-lg">
                <div className="text-sm text-gray-600 mb-1">ROI Mensal</div>
                <div className={`text-xl font-bold ${
                  projectionMode === 'units' 
                    ? ((results.netProfit && !isNaN(results.netProfit) ? (results.netProfit * parseFloat(dailyUnits) * 30) : 0) > (parseFloat(shopeeAdsInvestment) * 30) ? 'text-green-600' : 'text-red-600')
                    : (marketingMetrics.roiFromTarget >= 0 ? 'text-green-600' : 'text-red-600')
                }`}>
                  {projectionMode === 'units' 
                    ? ((results.netProfit && !isNaN(results.netProfit) ? (results.netProfit * parseFloat(dailyUnits) * 30) : 0) > 0 
                        ? (((results.netProfit * parseFloat(dailyUnits) * 30) - (parseFloat(shopeeAdsInvestment) * 30)) / (parseFloat(shopeeAdsInvestment) * 30) * 100).toFixed(1)
                        : '0.0')
                    : marketingMetrics.roiFromTarget.toFixed(1)
                  }%
                </div>
                <div className="text-xs text-gray-500">
                  {projectionMode === 'units' 
                    ? `Retorno sobre investimento com ${parseFloat(dailyUnits).toFixed(0)} unidades/dia`
                    : 'Retorno para atingir sua meta de lucro'
                  }
                </div>
              </div>
              <div className="bg-orange-50 p-4 rounded-lg">
                <div className="text-sm text-gray-600 mb-1">Payback</div>
                <div className="text-xl font-bold text-orange-600">
                  {projectionMode === 'units' 
                    ? ((results.netProfit && !isNaN(results.netProfit) && parseFloat(dailyUnits) > 0) 
                        ? (parseFloat(shopeeAdsInvestment) / (results.netProfit * parseFloat(dailyUnits))).toFixed(0)
                        : '0')
                    : marketingMetrics.paybackDaysFromTarget.toFixed(0)
                  } dias
                </div>
                <div className="text-xs text-gray-500">
                  {projectionMode === 'units' 
                    ? `Dias para recuperar investimento com ${parseFloat(dailyUnits).toFixed(0)} unidades/dia`
                    : 'Dias para recuperar investimento com sua meta'
                  }
                </div>
              </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="text-sm text-gray-600 mb-2">Projeção Mensal</div>
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <div className="text-xs text-gray-500">Investimento Ads</div>
                  <div className="text-lg font-bold text-orange-600">
                    R$ {(parseFloat(shopeeAdsInvestment) * 30).toFixed(2)}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">Lucro Bruto</div>
                  <div className="text-lg font-bold text-blue-600">
                    R$ {(results.grossProfit && !isNaN(results.grossProfit) 
                      ? projectionMode === 'units' 
                        ? (results.grossProfit * parseFloat(dailyUnits) * 30)
                        : (results.grossProfit * marketingMetrics.salesForDailyTarget * 30)
                      : 0).toFixed(2)}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">Lucro Líquido</div>
                  <div className="text-lg font-bold text-green-600">
                    R$ {(results.netProfit && !isNaN(results.netProfit)
                      ? projectionMode === 'units'
                        ? (results.netProfit * parseFloat(dailyUnits) * 30)
                        : (results.netProfit * marketingMetrics.salesForDailyTarget * 30)
                      : 0).toFixed(2)}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">Lucro Final (descontando ads)</div>
                  <div className={`text-lg font-bold ${
                    (results.netProfit && !isNaN(results.netProfit)
                      ? projectionMode === 'units'
                        ? (results.netProfit * parseFloat(dailyUnits) * 30)
                        : (results.netProfit * marketingMetrics.salesForDailyTarget * 30)
                      : 0) > (parseFloat(shopeeAdsInvestment) * 30) ? 'text-green-600' : 'text-red-600'
                  }`}>
                    R$ {((results.netProfit && !isNaN(results.netProfit)
                      ? projectionMode === 'units'
                        ? (results.netProfit * parseFloat(dailyUnits) * 30)
                        : (results.netProfit * marketingMetrics.salesForDailyTarget * 30)
                      : 0) - (parseFloat(shopeeAdsInvestment) * 30)).toFixed(2)}
                  </div>
                </div>
              </div>
              <div className="mt-3 text-xs text-gray-600 text-center">
                {projectionMode === 'units' 
                  ? `📊 Baseado em ${parseFloat(dailyUnits).toFixed(0)} unidades/dia`
                  : `📊 Baseado na meta de R$ ${parseFloat(dailyProfitTarget).toFixed(2)}/dia (${marketingMetrics.salesForDailyTarget.toFixed(1)} vendas/dia)`
                }
              </div>
            </div>
            
            <Button 
              onClick={calculateOptimalPrice}
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700"
            >
              {isLoading ? 'Calculando...' : 'Recalcular Preço Ideal'}
            </Button>
          </CardContent>
        </Card>

        {/* Simple Chart Visualization */}
        <Card className="shadow-lg border-0">
          <CardHeader className="bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-t-lg">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Relação Preço x Taxas x Lucro
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Preço de Venda</span>
                <div className="flex-1 mx-4 bg-gray-200 rounded-full h-4 relative">
                  <div 
                    className="bg-blue-500 h-4 rounded-full" 
                    style={{ width: `${Math.min((parseFloat(salePrice) / 200) * 100, 100)}%` }}
                  ></div>
                </div>
                <span className="text-sm font-semibold">R$ {salePrice}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Taxas Totais</span>
                <div className="flex-1 mx-4 bg-gray-200 rounded-full h-4 relative">
                  <div 
                    className="bg-red-500 h-4 rounded-full" 
                    style={{ width: `${Math.min((results.totalFees / parseFloat(salePrice)) * 100, 100)}%` }}
                  ></div>
                </div>
                <span className="text-sm font-semibold">R$ {results.totalFees.toFixed(2)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Lucro Líquido</span>
                <div className="flex-1 mx-4 bg-gray-200 rounded-full h-4 relative">
                  <div 
                    className={`${results.netProfit >= 0 ? 'bg-green-500' : 'bg-red-500'} h-4 rounded-full`}
                    style={{ width: `${Math.min(Math.abs(results.netProfit / parseFloat(salePrice)) * 100, 100)}%` }}
                  ></div>
                </div>
                <span className={`text-sm font-semibold ${results.netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  R$ {results.netProfit.toFixed(2)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}